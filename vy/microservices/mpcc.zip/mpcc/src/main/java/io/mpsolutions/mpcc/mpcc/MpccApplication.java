package io.mpsolutions.mpcc.mpcc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MpccApplication {

	public static void main(String[] args) {
		SpringApplication.run(MpccApplication.class, args);
	}

}
